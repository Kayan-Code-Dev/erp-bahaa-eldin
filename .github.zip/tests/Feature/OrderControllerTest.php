<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;
use App\Models\User;
use App\Models\Order;
use App\Models\Client;
use App\Models\Inventory;
use App\Models\Address;
use App\Models\Cloth;
use Laravel\Sanctum\Sanctum;

class OrderControllerTest extends TestCase
{
    use RefreshDatabase;

    public function test_index_returns_orders()
    {
        Order::factory()->count(3)->create();
        $user = User::factory()->create();
        Sanctum::actingAs($user);

        $response = $this->getJson('/api/v1/orders');

        $response->assertStatus(200)
            ->assertJsonStructure(['data', 'links']);
    }

    public function test_show_returns_order()
    {
        $order = Order::factory()->create();
        $user = User::factory()->create();
        Sanctum::actingAs($user);

        $response = $this->getJson("/api/v1/orders/{$order->id}");

        $response->assertStatus(200)
            ->assertJson(['id' => $order->id]);
    }

    public function test_store_creates_order()
    {
        $user = User::factory()->create();
        Sanctum::actingAs($user);

        $client = Client::factory()->create();
        $inventory = Inventory::factory()->create();
        $address = Address::factory()->create();
        $cloth = Cloth::factory()->create();

        $data = [
            'client_id' => $client->id,
            'inventory_id' => $inventory->id,
            'address_id' => $address->id,
            'total_price' => 100.00,
            'status' => 'pending',
            'clothes' => [
                [
                    'cloth_id' => $cloth->id,
                    'price' => 50.00,
                    'days_of_rent' => 3,
                ]
            ]
        ];
        
        $response = $this->postJson('/api/v1/orders', $data);

        $response->assertStatus(201)
            ->assertJson([
                'total_price' => 100.00,
                'status' => 'pending',
            ]);
        
        // Assert Pivot
        $this->assertDatabaseHas('cloth_order', [
            'cloth_id' => $cloth->id,
            'price' => 50.00
        ]);
    }

    public function test_update_updates_order()
    {
        $user = User::factory()->create();
        Sanctum::actingAs($user);

        $order = Order::factory()->create();
        $data = ['total_price' => 200.00];

        $response = $this->putJson("/api/v1/orders/{$order->id}", $data);

        $response->assertStatus(200)
            ->assertJson([
                'id' => $order->id,
                'total_price' => 200.00,
            ]);

        $this->assertDatabaseHas('orders', ['id' => $order->id, 'total_price' => 200.00]);
    }

    public function test_destroy_deletes_order()
    {
        $user = User::factory()->create();
        Sanctum::actingAs($user);

        $order = Order::factory()->create();

        $response = $this->deleteJson("/api/v1/orders/{$order->id}");

        $response->assertStatus(204);

        $this->assertSoftDeleted($order);
    }
}
