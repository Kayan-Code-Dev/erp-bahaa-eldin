<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;
use App\Models\User;
use App\Models\Cloth;
use Laravel\Sanctum\Sanctum;

class ClothControllerTest extends TestCase
{
    use RefreshDatabase;

    public function test_index_returns_clothes()
    {
        Cloth::factory()->count(3)->create();
        $user = User::factory()->create();
        Sanctum::actingAs($user);

        $response = $this->getJson('/api/v1/clothes');

        $response->assertStatus(200)
            ->assertJsonStructure(['data', 'links']);
    }

    public function test_show_returns_cloth()
    {
        $cloth = Cloth::factory()->create();
        $user = User::factory()->create();
        Sanctum::actingAs($user);

        $response = $this->getJson("/api/v1/clothes/{$cloth->id}");

        $response->assertStatus(200)
            ->assertJson(['id' => $cloth->id]);
    }

    public function test_store_creates_cloth()
    {
        $user = User::factory()->create();
        Sanctum::actingAs($user);

        $data = [
            'code' => 'TEST-001',
            'name' => 'Test Cloth',
            'breast_size' => '40',
        ];
        
        $response = $this->postJson('/api/v1/clothes', $data);

        $response->assertStatus(201)
            ->assertJson([
                'code' => 'TEST-001',
                'name' => 'Test Cloth',
            ]);
        
        $this->assertDatabaseHas('clothes', ['code' => 'TEST-001']);
    }

    public function test_update_updates_cloth()
    {
        $user = User::factory()->create();
        Sanctum::actingAs($user);

        $cloth = Cloth::factory()->create();
        $data = ['name' => 'Updated Cloth Name'];

        $response = $this->putJson("/api/v1/clothes/{$cloth->id}", $data);

        $response->assertStatus(200)
            ->assertJson([
                'id' => $cloth->id,
                'name' => 'Updated Cloth Name',
            ]);

        $this->assertDatabaseHas('clothes', ['id' => $cloth->id, 'name' => 'Updated Cloth Name']);
    }

    public function test_destroy_deletes_cloth()
    {
        $user = User::factory()->create();
        Sanctum::actingAs($user);

        $cloth = Cloth::factory()->create();

        $response = $this->deleteJson("/api/v1/clothes/{$cloth->id}");

        $response->assertStatus(204);

        $this->assertSoftDeleted($cloth);
    }
}
