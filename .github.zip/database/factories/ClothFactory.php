<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Cloth>
 */
class ClothFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'code' => $this->faker->unique()->bothify('CL-###'),
            'name' => $this->faker->word(),
            'description' => $this->faker->sentence(),
            'breast_size' => (string)$this->faker->numberBetween(30, 100),
            'waist_size' => (string)$this->faker->numberBetween(30, 100),
            'sleeve_size' => (string)$this->faker->numberBetween(30, 100),
            'delivery_date' => $this->faker->date(),
            'notes' => $this->faker->sentence(),
        ];
    }
}
