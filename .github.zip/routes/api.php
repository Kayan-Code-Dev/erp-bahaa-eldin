<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\ClientController;
use App\Http\Controllers\PhoneController;
use App\Http\Controllers\CountryController;
use App\Http\Controllers\CityController;
use App\Http\Controllers\AddressController;
use App\Http\Controllers\InventoryController;
use App\Http\Controllers\BranchController;
use App\Http\Controllers\ClothController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\SubcategoryController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\UserController;

// Versioned API (v1). Mounts v1 endpoints under /api/v1
// Apply API error middleware to all v1 routes so we return consistent JSON errors
Route::prefix('v1')->middleware(['force.json','api.error'])->group(function () {
	Route::post('/login', [AuthController::class, 'login']);

	// Protected endpoints (require Sanctum)
	Route::middleware('auth:sanctum')->group(function () {
        Route::post('/logout', [AuthController::class, 'logout']);
        
		Route::apiResource('clients', ClientController::class);
		Route::apiResource('phones', PhoneController::class);
		Route::apiResource('countries', CountryController::class);
		Route::apiResource('cities', CityController::class);
		Route::apiResource('addresses', AddressController::class);
		Route::apiResource('inventories', InventoryController::class);
		Route::apiResource('branches', BranchController::class);
		Route::apiResource('clothes', ClothController::class);
		Route::apiResource('categories', CategoryController::class);
		Route::apiResource('subcategories', SubcategoryController::class);
		Route::apiResource('orders', OrderController::class);
		Route::apiResource('roles', RoleController::class);
		Route::apiResource('users', UserController::class);
	});
});
