<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Route as RouteFacade;

use Illuminate\Support\Facades\Schema;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        Schema::defaultStringLength(191);

        // Register API error middleware alias so routes can use ->middleware('api.error')
        if ($this->app->bound('router')) {
            $this->app['router']->aliasMiddleware('api.error', \App\Http\Middleware\ApiExceptionMiddleware::class);
            $this->app['router']->aliasMiddleware('force.json', \App\Http\Middleware\ForceJson::class);
        }
    }
}
