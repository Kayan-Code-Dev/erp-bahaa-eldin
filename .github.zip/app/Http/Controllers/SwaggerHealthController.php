<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

/**
 * @OA\Info(
 *   title="Bahaa-Eldin API",
 *   version="1.0.0",
 * )
 */
class SwaggerHealthController extends Controller
{
    /**
     * @OA\Get(
     *   path="/api/health",
     *   tags={"Health"},
     *   summary="Health endpoint",
     *   @OA\Response(response=200, description="OK")
     * )
     */
    public function health(Request $request)
    {
        return response()->json(['status' => 'ok']);
    }
}
