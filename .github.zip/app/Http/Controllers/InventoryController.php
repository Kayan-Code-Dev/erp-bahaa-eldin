<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Inventory;

class InventoryController extends Controller
{
    /**
     * @OA\Get(
     *     path="/api/v1/inventories",
     *     summary="List all inventories",
     *     tags={"Inventories"},
     *     security={{"sanctum":{}}},
     *     @OA\Parameter(name="per_page", in="query", required=false, @OA\Schema(type="integer", default=15)),
     *     @OA\Response(response=200, description="Successful operation")
     * )
     */
    public function index(Request $request)
    {
        $perPage = (int) $request->query('per_page', 15);
        $items = Inventory::with(['city','address'])->paginate($perPage);
        return response()->json($items);
    }

    /**
     * @OA\Get(
     *     path="/api/v1/inventories/{id}",
     *     summary="Get an inventory by ID",
     *     tags={"Inventories"},
     *     security={{"sanctum":{}}},
     *     @OA\Parameter(name="id", in="path", required=true, @OA\Schema(type="integer")),
     *     @OA\Response(response=200, description="Successful operation"),
     *     @OA\Response(response=404, description="Resource not found")
     * )
     */
    public function show($id)
    {
        $item = Inventory::with(['city','address'])->findOrFail($id);
        return response()->json($item);
    }

    /**
     * @OA\Post(
     *     path="/api/v1/inventories",
     *     summary="Create a new inventory",
     *     tags={"Inventories"},
     *     security={{"sanctum":{}}},
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             required={"name", "type", "city_id", "address_id"},
     *             @OA\Property(property="name", type="string", example="Main Warehouse"),
     *             @OA\Property(property="type", type="string", enum={"inventory", "branch", "factory"}, example="inventory"),
     *             @OA\Property(property="city_id", type="integer", example=1),
     *             @OA\Property(property="address_id", type="integer", example=1)
     *         )
     *     ),
     *     @OA\Response(response=201, description="Inventory created"),
     *     @OA\Response(response=422, description="Validation error")
     * )
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string',
            'type' => 'required|in:inventory,branch,factory',
            'city_id' => 'required|exists:cities,id',
            'address_id' => 'required|exists:addresses,id',
        ]);

        $item = Inventory::create($data);
        return response()->json($item, 201);
    }

    /**
     * @OA\Put(
     *     path="/api/v1/inventories/{id}",
     *     summary="Update an inventory",
     *     tags={"Inventories"},
     *     security={{"sanctum":{}}},
     *     @OA\Parameter(name="id", in="path", required=true, @OA\Schema(type="integer")),
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             @OA\Property(property="name", type="string", example="Updated Warehouse"),
     *             @OA\Property(property="type", type="string", enum={"inventory", "branch", "factory"}, example="branch"),
     *             @OA\Property(property="city_id", type="integer", example=1),
     *             @OA\Property(property="address_id", type="integer", example=1)
     *         )
     *     ),
     *     @OA\Response(response=200, description="Inventory updated"),
     *     @OA\Response(response=404, description="Resource not found")
     * )
     */
    public function update(Request $request, $id)
    {
        $item = Inventory::findOrFail($id);
        $data = $request->validate([
            'name' => 'sometimes|required|string',
            'type' => 'sometimes|required|in:inventory,branch,factory',
            'city_id' => 'sometimes|required|exists:cities,id',
            'address_id' => 'sometimes|required|exists:addresses,id',
        ]);
        $item->update($data);
        return response()->json($item);
    }

    /**
     * @OA\Delete(
     *     path="/api/v1/inventories/{id}",
     *     summary="Delete an inventory",
     *     tags={"Inventories"},
     *     security={{"sanctum":{}}},
     *     @OA\Parameter(name="id", in="path", required=true, @OA\Schema(type="integer")),
     *     @OA\Response(response=204, description="Inventory deleted"),
     *     @OA\Response(response=404, description="Resource not found")
     * )
     */
    public function destroy($id)
    {
        $item = Inventory::findOrFail($id);
        $item->delete();
        return response()->json(null, 204);
    }
}
