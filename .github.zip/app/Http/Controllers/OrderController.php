<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Order;
use App\Models\Cloth;

class OrderController extends Controller
{
    /**
     * @OA\Get(
     *     path="/api/v1/orders",
     *     summary="List all orders",
     *     tags={"Orders"},
     *     security={{"sanctum":{}}},
     *     @OA\Parameter(name="per_page", in="query", required=false, @OA\Schema(type="integer", default=15)),
     *     @OA\Response(response=200, description="Successful operation")
     * )
     */
    public function index(Request $request)
    {
        $perPage = (int) $request->query('per_page', 15);
        $items = Order::with(['client','inventory','address','clothes'])->paginate($perPage);
        return response()->json($items);
    }

    /**
     * @OA\Get(
     *     path="/api/v1/orders/{id}",
     *     summary="Get an order by ID",
     *     tags={"Orders"},
     *     security={{"sanctum":{}}},
     *     @OA\Parameter(name="id", in="path", required=true, @OA\Schema(type="integer")),
     *     @OA\Response(response=200, description="Successful operation"),
     *     @OA\Response(response=404, description="Resource not found")
     * )
     */
    public function show($id)
    {
        $item = Order::with(['client','inventory','address','clothes'])->findOrFail($id);
        return response()->json($item);
    }

    /**
     * @OA\Post(
     *     path="/api/v1/orders",
     *     summary="Create a new order",
     *     tags={"Orders"},
     *     security={{"sanctum":{}}},
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             required={"client_id", "inventory_id", "address_id", "total_price", "clothes"},
     *             @OA\Property(property="client_id", type="integer", example=1),
     *             @OA\Property(property="inventory_id", type="integer", example=1),
     *             @OA\Property(property="address_id", type="integer", example=1),
     *             @OA\Property(property="total_price", type="number", format="float", example=100.50),
     *             @OA\Property(property="status", type="string", enum={"pending", "completed", "cancelled"}, example="pending"),
     *             @OA\Property(
     *                 property="clothes",
     *                 type="array",
     *                 @OA\Items(
     *                     required={"cloth_id"},
     *                     @OA\Property(property="cloth_id", type="integer", example=1),
     *                     @OA\Property(property="price", type="number", example=50.00),
     *                     @OA\Property(property="days_of_rent", type="integer", example=3),
     *                     @OA\Property(property="paid", type="number", example=20.00),
     *                     @OA\Property(property="remaining", type="number", example=30.00),
     *                     @OA\Property(property="visit_datetime", type="string", format="date-time"),
     *                     @OA\Property(property="occasion_datetime", type="string", format="date-time"),
     *                     @OA\Property(property="from_where_you_know_us", type="string"),
     *                     @OA\Property(property="status", type="string", enum={"rented","returned","late"})
     *                 )
     *             )
     *         )
     *     ),
     *     @OA\Response(response=201, description="Order created"),
     *     @OA\Response(response=422, description="Validation error")
     * )
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'client_id' => 'required|exists:clients,id',
            'inventory_id' => 'required|exists:inventories,id',
            'address_id' => 'required|exists:addresses,id',
            'total_price' => 'required|numeric',
            'status' => 'nullable|string',
            'clothes' => 'required|array',
            'clothes.*.cloth_id' => 'required|exists:clothes,id',
            'clothes.*.price' => 'nullable|numeric',
            'clothes.*.days_of_rent' => 'nullable|integer',
            'clothes.*.paid' => 'nullable|numeric',
            'clothes.*.remaining' => 'nullable|numeric',
            'clothes.*.visit_datetime' => 'nullable|date',
            'clothes.*.occasion_datetime' => 'nullable|date',
            'clothes.*.from_where_you_know_us' => 'nullable|string',
            'clothes.*.status' => 'nullable|string',
        ]);

        $order = Order::create([
            'client_id' => $data['client_id'],
            'inventory_id' => $data['inventory_id'],
            'address_id' => $data['address_id'],
            'total_price' => $data['total_price'],
            'status' => $data['status'] ?? 'pending',
        ]);

        // attach clothes pivot if provided
        if (isset($data['clothes'])) {
            foreach ($data['clothes'] as $row) {
                $pivot = [
                    'price' => $row['price'] ?? 0,
                    'days_of_rent' => $row['days_of_rent'] ?? 0,
                    'paid' => $row['paid'] ?? 0,
                    'remaining' => $row['remaining'] ?? 0,
                    'visit_datetime' => $row['visit_datetime'] ?? null,
                    'occasion_datetime' => $row['occasion_datetime'] ?? null,
                    'from_where_you_know_us' => $row['from_where_you_know_us'] ?? null,
                    'status' => $row['status'] ?? 'rented',
                ];
                $order->clothes()->attach($row['cloth_id'], $pivot);
            }
        }

        return response()->json($order->load('clothes'), 201);
    }

    /**
     * @OA\Put(
     *     path="/api/v1/orders/{id}",
     *     summary="Update an order",
     *     tags={"Orders"},
     *     security={{"sanctum":{}}},
     *     @OA\Parameter(name="id", in="path", required=true, @OA\Schema(type="integer")),
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             @OA\Property(property="total_price", type="number", example=120.00),
     *             @OA\Property(property="status", type="string", example="completed"),
     *             @OA\Property(
     *                 property="clothes",
     *                 type="array",
     *                 @OA\Items(
     *                     required={"cloth_id"},
     *                     @OA\Property(property="cloth_id", type="integer", example=1),
     *                     @OA\Property(property="price", type="number", example=60.00),
     *                     @OA\Property(property="days_of_rent", type="integer", example=3),
     *                     @OA\Property(property="paid", type="number", example=20.00),
     *                     @OA\Property(property="remaining", type="number", example=30.00),
     *                     @OA\Property(property="visit_datetime", type="string", format="date-time"),
     *                     @OA\Property(property="occasion_datetime", type="string", format="date-time"),
     *                     @OA\Property(property="from_where_you_know_us", type="string"),
     *                     @OA\Property(property="status", type="string", enum={"rented","returned","late"})
     *                 )
     *             )
     *         )
     *     ),
     *     @OA\Response(response=200, description="Order updated"),
     *     @OA\Response(response=404, description="Resource not found")
     * )
     */
    public function update(Request $request, $id)
    {
        $order = Order::findOrFail($id);
        $data = $request->validate([
            'client_id' => 'sometimes|required|exists:clients,id',
            'inventory_id' => 'sometimes|required|exists:inventories,id',
            'address_id' => 'sometimes|required|exists:addresses,id',
            'total_price' => 'sometimes|required|numeric',
            'status' => 'nullable|string',
            'clothes' => 'nullable|array',
            'clothes.*.cloth_id' => 'required_with:clothes|exists:clothes,id',
            'clothes.*.price' => 'nullable|numeric',
            'clothes.*.days_of_rent' => 'nullable|integer',
            'clothes.*.paid' => 'nullable|numeric',
            'clothes.*.remaining' => 'nullable|numeric',
            'clothes.*.visit_datetime' => 'nullable|date',
            'clothes.*.occasion_datetime' => 'nullable|date',
            'clothes.*.from_where_you_know_us' => 'nullable|string',
            'clothes.*.status' => 'nullable|string',
        ]);

        $order->update(collect($data)->except('clothes')->toArray());

        if (isset($data['clothes'])) {
            // sync with pivot data (replace existing)
            $syncData = [];
            foreach ($data['clothes'] as $row) {
                $syncData[$row['cloth_id']] = [
                    'price' => $row['price'] ?? 0,
                    'days_of_rent' => $row['days_of_rent'] ?? 0,
                    'paid' => $row['paid'] ?? 0,
                    'remaining' => $row['remaining'] ?? 0,
                    'visit_datetime' => $row['visit_datetime'] ?? null,
                    'occasion_datetime' => $row['occasion_datetime'] ?? null,
                    'from_where_you_know_us' => $row['from_where_you_know_us'] ?? null,
                    'status' => $row['status'] ?? 'rented',
                ];
            }
            $order->clothes()->sync($syncData);
        }

        return response()->json($order->load('clothes'));
    }

    /**
     * @OA\Delete(
     *     path="/api/v1/orders/{id}",
     *     summary="Delete an order",
     *     tags={"Orders"},
     *     security={{"sanctum":{}}},
     *     @OA\Parameter(name="id", in="path", required=true, @OA\Schema(type="integer")),
     *     @OA\Response(response=204, description="Order deleted"),
     *     @OA\Response(response=404, description="Resource not found")
     * )
     */
    public function destroy($id)
    {
        $item = Order::findOrFail($id);
        $item->delete();
        return response()->json(null, 204);
    }
}
