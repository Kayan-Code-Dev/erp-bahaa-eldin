<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Cloth;

class ClothController extends Controller
{
    /**
     * @OA\Get(
     *     path="/api/v1/clothes",
     *     summary="List all clothes",
     *     tags={"Clothes"},
     *     security={{"sanctum":{}}},
     *     @OA\Parameter(name="per_page", in="query", required=false, @OA\Schema(type="integer", default=15)),
     *     @OA\Response(response=200, description="Successful operation")
     * )
     */
    public function index(Request $request)
    {
        $perPage = (int) $request->query('per_page', 15);
        $items = Cloth::with(['subcategories','inventories','orders'])->paginate($perPage);
        return response()->json($items);
    }

    /**
     * @OA\Get(
     *     path="/api/v1/clothes/{id}",
     *     summary="Get a cloth by ID",
     *     tags={"Clothes"},
     *     security={{"sanctum":{}}},
     *     @OA\Parameter(name="id", in="path", required=true, @OA\Schema(type="integer")),
     *     @OA\Response(response=200, description="Successful operation"),
     *     @OA\Response(response=404, description="Resource not found")
     * )
     */
    public function show($id)
    {
        $item = Cloth::with(['subcategories','inventories','orders'])->findOrFail($id);
        return response()->json($item);
    }

    /**
     * @OA\Post(
     *     path="/api/v1/clothes",
     *     summary="Create a new cloth",
     *     tags={"Clothes"},
     *     security={{"sanctum":{}}},
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             required={"code", "name"},
     *             @OA\Property(property="code", type="string", example="CL-101"),
     *             @OA\Property(property="name", type="string", example="Red Dress"),
     *             @OA\Property(property="description", type="string", example="Evening dress"),
     *             @OA\Property(property="size", type="string", example="M"),
     *             @OA\Property(property="delivery_date", type="string", format="date", example="2025-01-01"),
     *             @OA\Property(property="notes", type="string", example="Handle with care")
     *         )
     *     ),
     *     @OA\Response(response=201, description="Cloth created"),
     *     @OA\Response(response=422, description="Validation error")
     * )
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'code' => 'required|string|unique:clothes,code',
            'name' => 'required|string',
            'description' => 'nullable|string',
            'size' => 'nullable|string',
            'per_size' => 'nullable|string',
            'waist_size' => 'nullable|string',
            'chest_size' => 'nullable|string',
            'hip_size' => 'nullable|string',
            'shoulder_size' => 'nullable|string',
            'delivery_date' => 'nullable|date',
            'notes' => 'nullable|string',
        ]);

        $item = Cloth::create($data);
        return response()->json($item, 201);
    }

    /**
     * @OA\Put(
     *     path="/api/v1/clothes/{id}",
     *     summary="Update a cloth",
     *     tags={"Clothes"},
     *     security={{"sanctum":{}}},
     *     @OA\Parameter(name="id", in="path", required=true, @OA\Schema(type="integer")),
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             @OA\Property(property="code", type="string", example="CL-101-UPDATED"),
     *             @OA\Property(property="name", type="string", example="Updated Red Dress")
     *         )
     *     ),
     *     @OA\Response(response=200, description="Cloth updated"),
     *     @OA\Response(response=404, description="Resource not found")
     * )
     */
    public function update(Request $request, $id)
    {
        $item = Cloth::findOrFail($id);
        $data = $request->validate([
            'code' => "sometimes|required|string|unique:clothes,code,{$id}",
            'name' => 'sometimes|required|string',
            'description' => 'nullable|string',
            'size' => 'nullable|string',
            'per_size' => 'nullable|string',
            'waist_size' => 'nullable|string',
            'chest_size' => 'nullable|string',
            'hip_size' => 'nullable|string',
            'shoulder_size' => 'nullable|string',
            'delivery_date' => 'nullable|date',
            'notes' => 'nullable|string',
        ]);
        $item->update($data);
        return response()->json($item);
    }

    /**
     * @OA\Delete(
     *     path="/api/v1/clothes/{id}",
     *     summary="Delete a cloth",
     *     tags={"Clothes"},
     *     security={{"sanctum":{}}},
     *     @OA\Parameter(name="id", in="path", required=true, @OA\Schema(type="integer")),
     *     @OA\Response(response=204, description="Cloth deleted"),
     *     @OA\Response(response=404, description="Resource not found")
     * )
     */
    public function destroy($id)
    {
        $item = Cloth::findOrFail($id);
        $item->delete();
        return response()->json(null, 204);
    }
}
