<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Phone;

class PhoneController extends Controller
{
    /**
     * @OA\Get(
     *     path="/api/v1/phones",
     *     summary="List all phones",
     *     tags={"Phones"},
     *     security={{"sanctum":{}}},
     *     @OA\Parameter(name="per_page", in="query", required=false, @OA\Schema(type="integer", default=15)),
     *     @OA\Response(response=200, description="Successful operation")
     * )
     */
    public function index(Request $request)
    {
        $perPage = (int) $request->query('per_page', 15);
        $items = Phone::with('client')->paginate($perPage);
        return response()->json($items);
    }

    /**
     * @OA\Get(
     *     path="/api/v1/phones/{id}",
     *     summary="Get a phone by ID",
     *     tags={"Phones"},
     *     security={{"sanctum":{}}},
     *     @OA\Parameter(name="id", in="path", required=true, @OA\Schema(type="integer")),
     *     @OA\Response(response=200, description="Successful operation"),
     *     @OA\Response(response=404, description="Resource not found")
     * )
     */
    public function show($id)
    {
        $item = Phone::with('client')->findOrFail($id);
        return response()->json($item);
    }

    /**
     * @OA\Post(
     *     path="/api/v1/phones",
     *     summary="Create a new phone",
     *     tags={"Phones"},
     *     security={{"sanctum":{}}},
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             required={"client_id", "phone"},
     *             @OA\Property(property="client_id", type="integer", example=1),
     *             @OA\Property(property="phone", type="string", example="01234567890"),
     *             @OA\Property(property="type", type="string", enum={"mobile", "landline", "whatsapp"}, example="mobile")
     *         )
     *     ),
     *     @OA\Response(response=201, description="Phone created"),
     *     @OA\Response(response=422, description="Validation error")
     * )
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'client_id' => 'required|exists:clients,id',
            'phone' => 'required|string',
            'type' => 'required|in:mobile,landline,whatsapp',
        ]);

        $item = Phone::create($data);
        return response()->json($item, 201);
    }

    /**
     * @OA\Put(
     *     path="/api/v1/phones/{id}",
     *     summary="Update a phone",
     *     tags={"Phones"},
     *     security={{"sanctum":{}}},
     *     @OA\Parameter(name="id", in="path", required=true, @OA\Schema(type="integer")),
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             @OA\Property(property="client_id", type="integer", example=1),
     *             @OA\Property(property="phone", type="string", example="01234567891"),
     *             @OA\Property(property="type", type="string", enum={"mobile", "landline", "whatsapp"}, example="whatsapp")
     *         )
     *     ),
     *     @OA\Response(response=200, description="Phone updated"),
     *     @OA\Response(response=404, description="Resource not found")
     * )
     */
    public function update(Request $request, $id)
    {
        $item = Phone::findOrFail($id);
        $data = $request->validate([
            'client_id' => 'sometimes|required|exists:clients,id',
            'phone' => 'sometimes|required|string',
            'type' => 'sometimes|required|in:mobile,landline,whatsapp',
        ]);
        $item->update($data);
        return response()->json($item);
    }

    /**
     * @OA\Delete(
     *     path="/api/v1/phones/{id}",
     *     summary="Delete a phone",
     *     tags={"Phones"},
     *     security={{"sanctum":{}}},
     *     @OA\Parameter(name="id", in="path", required=true, @OA\Schema(type="integer")),
     *     @OA\Response(response=204, description="Phone deleted"),
     *     @OA\Response(response=404, description="Resource not found")
     * )
     */
    public function destroy($id)
    {
        $item = Phone::findOrFail($id);
        $item->delete();
        return response()->json(null, 204);
    }
}
