<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Branch;

class BranchController extends Controller
{
    /**
     * @OA\Get(
     *     path="/api/v1/branches",
     *     summary="List all branches",
     *     tags={"Branches"},
     *     security={{"sanctum":{}}},
     *     @OA\Parameter(name="per_page", in="query", required=false, @OA\Schema(type="integer", default=15)),
     *     @OA\Response(response=200, description="Successful operation")
     * )
     */
    public function index(Request $request)
    {
        $perPage = (int) $request->query('per_page', 15);
        $items = Branch::with(['inventory','address'])->paginate($perPage);
        return response()->json($items);
    }

    /**
     * @OA\Get(
     *     path="/api/v1/branches/{id}",
     *     summary="Get a branch by ID",
     *     tags={"Branches"},
     *     security={{"sanctum":{}}},
     *     @OA\Parameter(name="id", in="path", required=true, @OA\Schema(type="integer")),
     *     @OA\Response(response=200, description="Successful operation"),
     *     @OA\Response(response=404, description="Resource not found")
     * )
     */
    public function show($id)
    {
        $item = Branch::with(['inventory','address'])->findOrFail($id);
        return response()->json($item);
    }

    /**
     * @OA\Post(
     *     path="/api/v1/branches",
     *     summary="Create a new branch",
     *     tags={"Branches"},
     *     security={{"sanctum":{}}},
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             required={"inventory_id", "branch_code", "name", "address_id"},
     *             @OA\Property(property="inventory_id", type="integer", example=1),
     *             @OA\Property(property="branch_code", type="string", example="BR-001"),
     *             @OA\Property(property="name", type="string", example="Downtown Branch"),
     *             @OA\Property(property="address_id", type="integer", example=1)
     *         )
     *     ),
     *     @OA\Response(response=201, description="Branch created"),
     *     @OA\Response(response=422, description="Validation error")
     * )
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'inventory_id' => 'required|exists:inventories,id',
            'branch_code' => 'required|string|unique:branches,branch_code',
            'name' => 'required|string',
            'address_id' => 'required|exists:addresses,id',
        ]);

        $item = Branch::create($data);
        return response()->json($item, 201);
    }

    /**
     * @OA\Put(
     *     path="/api/v1/branches/{id}",
     *     summary="Update a branch",
     *     tags={"Branches"},
     *     security={{"sanctum":{}}},
     *     @OA\Parameter(name="id", in="path", required=true, @OA\Schema(type="integer")),
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             @OA\Property(property="inventory_id", type="integer", example=1),
     *             @OA\Property(property="branch_code", type="string", example="BR-001-UPDATED"),
     *             @OA\Property(property="name", type="string", example="Uptown Branch"),
     *             @OA\Property(property="address_id", type="integer", example=1)
     *         )
     *     ),
     *     @OA\Response(response=200, description="Branch updated"),
     *     @OA\Response(response=404, description="Resource not found")
     * )
     */
    public function update(Request $request, $id)
    {
        $item = Branch::findOrFail($id);
        $data = $request->validate([
            'inventory_id' => 'sometimes|required|exists:inventories,id',
            'branch_code' => "sometimes|required|string|unique:branches,branch_code,{$id}",
            'name' => 'sometimes|required|string',
            'address_id' => 'sometimes|required|exists:addresses,id',
        ]);
        $item->update($data);
        return response()->json($item);
    }

    /**
     * @OA\Delete(
     *     path="/api/v1/branches/{id}",
     *     summary="Delete a branch",
     *     tags={"Branches"},
     *     security={{"sanctum":{}}},
     *     @OA\Parameter(name="id", in="path", required=true, @OA\Schema(type="integer")),
     *     @OA\Response(response=204, description="Branch deleted"),
     *     @OA\Response(response=404, description="Resource not found")
     * )
     */
    public function destroy($id)
    {
        $item = Branch::findOrFail($id);
        $item->delete();
        return response()->json(null, 204);
    }
}
