<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Address extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = ['street', 'building', 'notes', 'city_id'];

    public function city()
    {
        return $this->belongsTo(City::class);
    }

    public function inventories()
    {
        return $this->hasMany(Inventory::class);
    }

    public function branches()
    {
        return $this->hasMany(Branch::class);
    }

    public function orders()
    {
        return $this->hasMany(Order::class);
    }
}
