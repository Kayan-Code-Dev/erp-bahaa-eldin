<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Inventory extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = ['name', 'type', 'city_id', 'address_id'];

    public function city()
    {
        return $this->belongsTo(City::class);
    }

    public function address()
    {
        return $this->belongsTo(Address::class);
    }

    public function branches()
    {
        return $this->hasMany(Branch::class);
    }

    public function clothes()
    {
        return $this->belongsToMany(Cloth::class, 'cloth_inventory')
                    ->withPivot('quantity', 'available_quantity')
                    ->withTimestamps();
    }

    public function orders()
    {
        return $this->hasMany(Order::class);
    }
}
