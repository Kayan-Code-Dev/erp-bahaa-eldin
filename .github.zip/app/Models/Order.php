<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Order extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'client_id',
        'inventory_id',
        'address_id',
        'total_price',
        'status',
    ];

    public function client()
    {
        return $this->belongsTo(Client::class);
    }

    public function inventory()
    {
        return $this->belongsTo(Inventory::class);
    }

    public function address()
    {
        return $this->belongsTo(Address::class);
    }

    public function clothes()
    {
        return $this->belongsToMany(Cloth::class, 'cloth_order')
                    ->withPivot([
                        'price',
                        'days_of_rent',
                        'paid',
                        'remaining',
                        'visit_datetime',
                        'occasion_datetime',
                        'from_where_you_know_us',
                        'status',
                    ])
                    ->withTimestamps();
    }
}
