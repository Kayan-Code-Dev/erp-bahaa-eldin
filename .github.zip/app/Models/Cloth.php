<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Cloth extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'clothes';

    protected $fillable = [
        'code',
        'name',
        'description',
        'breast_size',
        'waist_size',
        'sleeve_size',
        'delivery_date',
        'notes',
    ];

    public function inventories()
    {
        return $this->belongsToMany(Inventory::class, 'cloth_inventory')
                    ->withPivot('quantity', 'available_quantity')
                    ->withTimestamps();
    }

    public function subcategories()
    {
        return $this->belongsToMany(Subcategory::class, 'cloth_subcategory')
                    ->withTimestamps();
    }

    public function orders()
    {
        return $this->belongsToMany(Order::class, 'cloth_order')
                    ->withPivot([
                        'price',
                        'days_of_rent',
                        'paid',
                        'remaining',
                        'visit_datetime',
                        'occasion_datetime',
                        'from_where_you_know_us',
                        'status',
                    ])
                    ->withTimestamps();
    }
}
