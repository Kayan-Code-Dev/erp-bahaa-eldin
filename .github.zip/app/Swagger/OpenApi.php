<?php

/**
 * @OA\OpenApi(
 *   @OA\Info(
 *     title="Bahaa-Eldin API",
 *     version="1.0.0",
 *     description="Auto-generated OpenAPI documentation"
 *   ),
 *   @OA\PathItem(
 *     path="/api/health",
 *     @OA\Get(
 *       tags={"Health"},
 *       summary="Health check",
 *       @OA\Response(response=200, description="OK")
 *     )
 *   )
 * )
 */

// nothing to execute in this file; it's only for annotations
