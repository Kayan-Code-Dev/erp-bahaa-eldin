<?php

/**
 * @OA\Info(
 *   title="Bahaa-Eldin API",
 *   version="1.0.0",
 *   description="Auto-generated OpenAPI documentation"
 * )
 */

// File contains only OpenAPI Info annotation
