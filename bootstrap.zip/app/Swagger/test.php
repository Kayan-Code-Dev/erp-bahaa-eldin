<?php

/**
 * @OA\Get(
 *   path="/api/test",
 *   summary="Test endpoint",
 *   @OA\Response(response=200, description="Success")
 * )
 */

// Test file for swagger scanning
