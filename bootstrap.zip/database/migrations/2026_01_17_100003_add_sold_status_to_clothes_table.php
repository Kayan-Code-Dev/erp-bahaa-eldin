<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     * 
     * Adds 'sold' status to the clothes status enum.
     * This status is used when a cloth is purchased (buy order delivered).
     */
    public function up(): void
    {
        $driver = Schema::getConnection()->getDriverName();
        
        if ($driver === 'mysql') {
            // MySQL: Alter enum directly
            DB::statement("ALTER TABLE clothes MODIFY COLUMN status ENUM('damaged', 'burned', 'scratched', 'ready_for_rent', 'rented', 'repairing', 'die', 'sold') DEFAULT 'ready_for_rent'");
        } else {
            // SQLite: Recreate table approach
            $clothes = DB::table('clothes')->get();
            
            Schema::dropIfExists('clothes_new');
            
            Schema::create('clothes_new', function (Blueprint $table) {
                $table->id();
                $table->string('code')->unique();
                $table->string('name');
                $table->text('description')->nullable();
                $table->foreignId('cloth_type_id')->nullable()->constrained('cloth_types')->onDelete('set null');
                $table->string('breast_size')->nullable();
                $table->string('waist_size')->nullable();
                $table->string('sleeve_size')->nullable();
                $table->text('notes')->nullable();
                $table->string('status')->default('ready_for_rent');
                $table->timestamps();
                $table->softDeletes();
            });
            
            foreach ($clothes as $cloth) {
                DB::table('clothes_new')->insert([
                    'id' => $cloth->id,
                    'code' => $cloth->code,
                    'name' => $cloth->name,
                    'description' => $cloth->description,
                    'cloth_type_id' => $cloth->cloth_type_id,
                    'breast_size' => $cloth->breast_size,
                    'waist_size' => $cloth->waist_size,
                    'sleeve_size' => $cloth->sleeve_size,
                    'notes' => $cloth->notes,
                    'status' => $cloth->status,
                    'created_at' => $cloth->created_at,
                    'updated_at' => $cloth->updated_at,
                    'deleted_at' => $cloth->deleted_at,
                ]);
            }
            
            Schema::drop('clothes');
            Schema::rename('clothes_new', 'clothes');
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        $driver = Schema::getConnection()->getDriverName();
        
        if ($driver === 'mysql') {
            // First update any 'sold' status to 'ready_for_rent' to avoid data loss
            DB::statement("UPDATE clothes SET status = 'ready_for_rent' WHERE status = 'sold'");
            
            // MySQL: Alter enum back
            DB::statement("ALTER TABLE clothes MODIFY COLUMN status ENUM('damaged', 'burned', 'scratched', 'ready_for_rent', 'rented', 'repairing', 'die') DEFAULT 'ready_for_rent'");
        } else {
            // SQLite: Update sold to ready_for_rent
            DB::statement("UPDATE clothes SET status = 'ready_for_rent' WHERE status = 'sold'");
        }
    }
};

