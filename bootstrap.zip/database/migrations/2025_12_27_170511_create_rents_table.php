<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('rents', function (Blueprint $table) {
            $table->id();
            $table->foreignId('cloth_id')->constrained('clothes')->onDelete('cascade');
            $table->foreignId('order_id')->constrained('orders')->onDelete('cascade');
            $table->foreignId('cloth_order_id')->constrained('cloth_order')->onDelete('cascade');
            $table->date('delivery_date');
            $table->date('return_date'); // Calculated: delivery_date + days_of_rent
            $table->integer('days_of_rent');
            $table->enum('status', ['active', 'completed', 'canceled'])->default('active');
            $table->timestamps();

            // Indexes for availability queries
            $table->index('cloth_id');
            $table->index('delivery_date');
            $table->index('return_date');
            $table->index(['cloth_id', 'status']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('rents');
    }
};
