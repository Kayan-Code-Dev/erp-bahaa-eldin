<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     * 
     * Adds branch_id to workshops table to establish 1:1 relationship
     * between branches and workshops (each branch has exactly one workshop)
     */
    public function up(): void
    {
        Schema::table('workshops', function (Blueprint $table) {
            $table->foreignId('branch_id')
                ->nullable()
                ->unique()
                ->after('address_id')
                ->constrained('branches')
                ->onDelete('set null');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('workshops', function (Blueprint $table) {
            $table->dropForeign(['branch_id']);
            $table->dropColumn('branch_id');
        });
    }
};





