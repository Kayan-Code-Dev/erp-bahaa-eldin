<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     * 
     * Extend the rents table to handle all appointment types:
     * - rental_delivery: When dress is given to client
     * - rental_return: When dress is returned by client  
     * - measurement: Client measurement appointment
     * - tailoring_pickup: Pick up tailored dress from factory
     * - tailoring_delivery: Deliver tailored dress to client
     * - fitting: Dress fitting appointment
     * - other: General appointments
     */
    public function up(): void
    {
        // For SQLite, we need to recreate the table to modify column constraints
        // First, backup existing data
        $existingRents = DB::table('rents')->get();
        
        // Drop the existing table
        Schema::dropIfExists('rents');
        
        // Create the new table with all columns nullable where needed
        Schema::create('rents', function (Blueprint $table) {
            $table->id();
            
            // Client and branch for appointment tracking
            $table->foreignId('client_id')->nullable()->constrained('clients')->onDelete('cascade');
            $table->foreignId('branch_id')->nullable()->constrained('branches')->onDelete('set null');
            
            // Original rental-related columns - now nullable for non-rental appointments
            $table->foreignId('cloth_id')->nullable()->constrained('clothes')->onDelete('cascade');
            $table->foreignId('order_id')->nullable()->constrained('orders')->onDelete('cascade');
            $table->foreignId('cloth_order_id')->nullable()->constrained('cloth_order')->onDelete('cascade');
            
            // Appointment type and title
            $table->string('appointment_type')->default('rental_delivery');
            $table->string('title')->nullable();
            
            // Date and time fields
            $table->date('delivery_date');
            $table->time('appointment_time')->nullable();
            $table->date('return_date')->nullable(); // Now nullable for non-rental appointments
            $table->time('return_time')->nullable();
            $table->integer('days_of_rent')->nullable(); // Now nullable
            
            // Status - expanded from original enum
            $table->string('status')->default('scheduled');
            
            // Notes field
            $table->text('notes')->nullable();
            
            // Reminder tracking
            $table->boolean('reminder_sent')->default(false);
            $table->timestamp('reminder_sent_at')->nullable();
            
            // Audit fields
            $table->foreignId('created_by')->nullable()->constrained('users')->onDelete('set null');
            $table->timestamp('completed_at')->nullable();
            $table->foreignId('completed_by')->nullable()->constrained('users')->onDelete('set null');
            
            $table->timestamps();

            // Indexes for queries
            $table->index('cloth_id');
            $table->index('delivery_date');
            $table->index('return_date');
            $table->index(['cloth_id', 'status']);
            $table->index('appointment_type');
            $table->index('client_id');
            $table->index('branch_id');
            $table->index(['appointment_type', 'status']);
            $table->index(['delivery_date', 'appointment_time']);
        });
        
        // Restore existing data with defaults for new columns
        foreach ($existingRents as $rent) {
            DB::table('rents')->insert([
                'id' => $rent->id,
                'client_id' => null,
                'branch_id' => null,
                'cloth_id' => $rent->cloth_id,
                'order_id' => $rent->order_id,
                'cloth_order_id' => $rent->cloth_order_id,
                'appointment_type' => 'rental_delivery',
                'title' => null,
                'delivery_date' => $rent->delivery_date,
                'appointment_time' => null,
                'return_date' => $rent->return_date,
                'return_time' => null,
                'days_of_rent' => $rent->days_of_rent,
                'status' => $rent->status,
                'notes' => null,
                'reminder_sent' => false,
                'reminder_sent_at' => null,
                'created_by' => null,
                'completed_at' => null,
                'completed_by' => null,
                'created_at' => $rent->created_at,
                'updated_at' => $rent->updated_at,
            ]);
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // Backup existing data
        $existingRents = DB::table('rents')->get();
        
        // Drop the modified table
        Schema::dropIfExists('rents');
        
        // Recreate original table
        Schema::create('rents', function (Blueprint $table) {
            $table->id();
            $table->foreignId('cloth_id')->constrained('clothes')->onDelete('cascade');
            $table->foreignId('order_id')->constrained('orders')->onDelete('cascade');
            $table->foreignId('cloth_order_id')->constrained('cloth_order')->onDelete('cascade');
            $table->date('delivery_date');
            $table->date('return_date');
            $table->integer('days_of_rent');
            $table->enum('status', ['active', 'completed', 'canceled'])->default('active');
            $table->timestamps();

            $table->index('cloth_id');
            $table->index('delivery_date');
            $table->index('return_date');
            $table->index(['cloth_id', 'status']);
        });
        
        // Restore only rental appointments that have required fields
        foreach ($existingRents as $rent) {
            if ($rent->cloth_id && $rent->order_id && $rent->cloth_order_id && $rent->return_date && $rent->days_of_rent) {
                // Map new statuses to old enum values
                $status = match($rent->status) {
                    'scheduled', 'confirmed', 'in_progress', 'active' => 'active',
                    'completed' => 'completed',
                    'cancelled', 'canceled', 'no_show', 'rescheduled' => 'canceled',
                    default => 'active',
                };
                
                DB::table('rents')->insert([
                    'id' => $rent->id,
                    'cloth_id' => $rent->cloth_id,
                    'order_id' => $rent->order_id,
                    'cloth_order_id' => $rent->cloth_order_id,
                    'delivery_date' => $rent->delivery_date,
                    'return_date' => $rent->return_date,
                    'days_of_rent' => $rent->days_of_rent,
                    'status' => $status,
                    'created_at' => $rent->created_at,
                    'updated_at' => $rent->updated_at,
                ]);
            }
        }
    }
};
