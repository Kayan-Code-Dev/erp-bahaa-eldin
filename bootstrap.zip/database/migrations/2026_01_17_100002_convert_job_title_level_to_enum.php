<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     * 
     * Converts the level column from integer to enum with 4 values:
     * - master_manager (was 1)
     * - branches_manager (was 2)
     * - branch_manager (was 3)
     * - employee (was 4, default)
     */
    public function up(): void
    {
        // For SQLite, we need to recreate the table
        // For MySQL/PostgreSQL, we could use ALTER TABLE directly
        
        $driver = Schema::getConnection()->getDriverName();
        
        if ($driver === 'sqlite') {
            // SQLite approach: Create new table, copy data, drop old, rename new
            
            // Get existing data
            $jobTitles = DB::table('job_titles')->get();
            
            // Create temporary table with new schema
            Schema::create('job_titles_new', function (Blueprint $table) {
                $table->id();
                $table->string('code')->unique();
                $table->string('name');
                $table->text('description')->nullable();
                $table->foreignId('department_id')->nullable()->constrained('departments')->onDelete('set null');
                $table->string('level')->default('employee');
                $table->decimal('min_salary', 12, 2)->nullable();
                $table->decimal('max_salary', 12, 2)->nullable();
                $table->boolean('is_active')->default(true);
                $table->timestamps();
                $table->softDeletes();

                $table->index('department_id');
                $table->index('level');
                $table->index('is_active');
            });
            
            // Copy data with level conversion
            foreach ($jobTitles as $jobTitle) {
                $newLevel = match ((int)$jobTitle->level) {
                    1 => 'master_manager',
                    2 => 'branches_manager',
                    3 => 'branch_manager',
                    default => 'employee',
                };
                
                DB::table('job_titles_new')->insert([
                    'id' => $jobTitle->id,
                    'code' => $jobTitle->code,
                    'name' => $jobTitle->name,
                    'description' => $jobTitle->description,
                    'department_id' => $jobTitle->department_id,
                    'level' => $newLevel,
                    'min_salary' => $jobTitle->min_salary,
                    'max_salary' => $jobTitle->max_salary,
                    'is_active' => $jobTitle->is_active,
                    'created_at' => $jobTitle->created_at,
                    'updated_at' => $jobTitle->updated_at,
                    'deleted_at' => $jobTitle->deleted_at,
                ]);
            }
            
            // Drop old table and rename new one
            Schema::drop('job_titles');
            Schema::rename('job_titles_new', 'job_titles');
            
        } else {
            // MySQL/PostgreSQL approach
            
            // First, add a temporary column with the new string type
            Schema::table('job_titles', function (Blueprint $table) {
                $table->string('level_new')->default('employee')->after('level');
            });

            // Map old integer values to new enum values
            DB::statement("UPDATE job_titles SET level_new = CASE 
                WHEN level = 1 THEN 'master_manager'
                WHEN level = 2 THEN 'branches_manager'
                WHEN level = 3 THEN 'branch_manager'
                ELSE 'employee'
            END");

            // Drop the old index first
            Schema::table('job_titles', function (Blueprint $table) {
                $table->dropIndex(['level']);
            });

            // Drop the old column
            Schema::table('job_titles', function (Blueprint $table) {
                $table->dropColumn('level');
            });

            // Rename the new column
            Schema::table('job_titles', function (Blueprint $table) {
                $table->renameColumn('level_new', 'level');
            });

            // Add index on level column
            Schema::table('job_titles', function (Blueprint $table) {
                $table->index('level');
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        $driver = Schema::getConnection()->getDriverName();
        
        if ($driver === 'sqlite') {
            // SQLite approach: Create new table, copy data, drop old, rename new
            
            // Get existing data
            $jobTitles = DB::table('job_titles')->get();
            
            // Create temporary table with old schema
            Schema::create('job_titles_new', function (Blueprint $table) {
                $table->id();
                $table->string('code')->unique();
                $table->string('name');
                $table->text('description')->nullable();
                $table->foreignId('department_id')->nullable()->constrained('departments')->onDelete('set null');
                $table->unsignedTinyInteger('level')->default(4);
                $table->decimal('min_salary', 12, 2)->nullable();
                $table->decimal('max_salary', 12, 2)->nullable();
                $table->boolean('is_active')->default(true);
                $table->timestamps();
                $table->softDeletes();

                $table->index('department_id');
                $table->index('level');
                $table->index('is_active');
            });
            
            // Copy data with level conversion back to integer
            foreach ($jobTitles as $jobTitle) {
                $oldLevel = match ($jobTitle->level) {
                    'master_manager' => 1,
                    'branches_manager' => 2,
                    'branch_manager' => 3,
                    default => 4,
                };
                
                DB::table('job_titles_new')->insert([
                    'id' => $jobTitle->id,
                    'code' => $jobTitle->code,
                    'name' => $jobTitle->name,
                    'description' => $jobTitle->description,
                    'department_id' => $jobTitle->department_id,
                    'level' => $oldLevel,
                    'min_salary' => $jobTitle->min_salary,
                    'max_salary' => $jobTitle->max_salary,
                    'is_active' => $jobTitle->is_active,
                    'created_at' => $jobTitle->created_at,
                    'updated_at' => $jobTitle->updated_at,
                    'deleted_at' => $jobTitle->deleted_at,
                ]);
            }
            
            // Drop old table and rename new one
            Schema::drop('job_titles');
            Schema::rename('job_titles_new', 'job_titles');
            
        } else {
            // MySQL/PostgreSQL approach
            
            // Drop index first
            Schema::table('job_titles', function (Blueprint $table) {
                $table->dropIndex(['level']);
            });

            // Add temporary integer column
            Schema::table('job_titles', function (Blueprint $table) {
                $table->unsignedTinyInteger('level_old')->default(4)->after('level');
            });

            // Map enum values back to integers
            DB::statement("UPDATE job_titles SET level_old = CASE 
                WHEN level = 'master_manager' THEN 1
                WHEN level = 'branches_manager' THEN 2
                WHEN level = 'branch_manager' THEN 3
                ELSE 4
            END");

            // Drop the string column
            Schema::table('job_titles', function (Blueprint $table) {
                $table->dropColumn('level');
            });

            // Rename the integer column
            Schema::table('job_titles', function (Blueprint $table) {
                $table->renameColumn('level_old', 'level');
            });

            // Add index on level column
            Schema::table('job_titles', function (Blueprint $table) {
                $table->index('level');
            });
        }
    }
};
